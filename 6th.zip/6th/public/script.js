document.addEventListener("DOMContentLoaded", () => {
    console.log("Static website loaded with JS successfully.");
  });
  